// Amethyst - new window logic. Runs in the Windows built-in browser engine (IE11 mode):
// plain ES5 only - var/function, no arrow functions, no let/const, no template strings.
// The AutoHotkey host puts an object on window.ahk with:
//   Get(file, sec, key, def)  Set(file, sec, key, val)  Profiles()  ActiveProfile()
//   SetProfile(name)  RobloxOpen()  Exit()  Reload()  OnTop(on)
// file is "settings" (Settings.ini) or "profile" (the active Profiles\*.ini).

window.onerror = function (msg, url, line) {
  var el = document.getElementById("saveMsg");
  if (el) { el.className = "bad"; el.innerHTML = "Script error (line " + line + "): " + msg; }
  return true;
};

function hasClass(el, c) { return (" " + el.className + " ").indexOf(" " + c + " ") >= 0; }
function addClass(el, c) { if (!hasClass(el, c)) el.className = (el.className + " " + c).replace(/^\s+/, ""); }
function delClass(el, c) { el.className = (" " + el.className + " ").replace(" " + c + " ", " ").replace(/^\s+|\s+$/g, ""); }
function each(list, fn) { for (var i = 0; i < list.length; i++) fn(list[i], i); }
function $(id) { return document.getElementById(id); }

// "totem" settings live in Settings.ini when they are shared across profiles, otherwise in the profile.
function fileOf(el) {
  var f = el.getAttribute("data-file") || "profile";
  if (f === "totem") return String(ahk.Get("settings", "Totem", "Global", "0")) === "1" ? "settings" : "profile";
  return f;
}
function readVal(el) { return String(ahk.Get(fileOf(el), el.getAttribute("data-sec"), el.getAttribute("data-key"), el.getAttribute("data-def") || "")); }
function writeVal(el, v) { ahk.Set(fileOf(el), el.getAttribute("data-sec"), el.getAttribute("data-key"), String(v)); }

// ---------- save bar ----------
var saveTimer = null;
function flash(text, cls) {
  var el = $("saveMsg");
  el.className = cls || "ok";
  el.innerHTML = text;
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(function () { el.className = ""; el.innerHTML = "Changes save automatically."; }, 2200);
}

// ---------- tabs ----------
function showPage(name) {
  each(document.querySelectorAll(".tab"), function (t) {
    if (t.getAttribute("data-page") === name) addClass(t, "active"); else delClass(t, "active");
  });
  each(document.querySelectorAll(".page"), function (p) {
    if (p.id === "page-" + name) addClass(p, "active"); else delClass(p, "active");
  });
  $("content").scrollTop = 0;
}

// ---------- collapsible cards ----------
function cardId(card, i) {
  var head = card.querySelector(".card-head");
  var page = card.parentNode.id || "page";
  // update-log cards are remembered by their version, so a new release does not shift them
  if (hasClass(card, "log-card") && head) {
    var m = head.innerText.match(/Version\s*([0-9.]+)/);
    if (m) return "log_" + m[1].replace(/\./g, "_");
  }
  return (page + "_" + i).replace(/[^A-Za-z0-9_]/g, "");
}
function setupCards() {
  each(document.querySelectorAll(".page"), function (page) {
    each(page.querySelectorAll(".card"), function (card, i) {
      var head = card.querySelector(".card-head");
      if (!head) return;
      var id = cardId(card, i);
      if (String(ahk.Get("settings", "GUIv2", "Collapsed_" + id, card.getAttribute("data-start-collapsed") || "0")) === "1") addClass(card, "collapsed");
      head.onclick = function () {
        if (hasClass(card, "collapsed")) { delClass(card, "collapsed"); ahk.Set("settings", "GUIv2", "Collapsed_" + id, "0"); }
        else { addClass(card, "collapsed"); ahk.Set("settings", "GUIv2", "Collapsed_" + id, "1"); }
      };
    });
  });
}

// ---------- toggle switches ----------
function isOn(el, raw) {
  raw = String(raw).toLowerCase();
  return raw === "true" || raw === "1";
}
function loadSwitches() {
  each(document.querySelectorAll(".switch"), function (sw) {
    if (isOn(sw, readVal(sw))) addClass(sw, "on"); else delClass(sw, "on");
  });
}
function setupSwitches() {
  each(document.querySelectorAll(".switch"), function (sw) {
    sw.onclick = function (e) {
      e = e || window.event;
      if (e) { if (e.stopPropagation) e.stopPropagation(); e.cancelBubble = true; }  // a switch in a card header must not fold the card
      if (sw.getAttribute("data-locked")) { flash("Auto-zoom stays off while Cast mode is Perfect.", "bad"); return; }
      var on = !hasClass(sw, "on");
      if (on) addClass(sw, "on"); else delClass(sw, "on");
      var fmt01 = sw.getAttribute("data-fmt") === "01";
      writeVal(sw, fmt01 ? (on ? "1" : "0") : (on ? "true" : "false"));
      if (sw.getAttribute("data-key") === "AlwaysOnTop") ahk.OnTop(on ? 1 : 0);
      if (sw.id === "totemGlobal") { loadAll(); flash(on ? "Totem settings are now shared by every profile." : "Totem settings are now kept per profile."); return; }
      flash("Saved.");
      refreshUtil();
      refreshChecks();
    };
  });
}

// ---------- text / number boxes ----------
function loadInputs() {
  each(document.querySelectorAll("input.input"), function (inp) {
    inp.value = readVal(inp);
    delClass(inp, "bad");
  });
}
function validNum(v) { return /^\d{1,7}$/.test(v); }
function validDec(v) { return /^-?\d{1,5}(\.\d{1,3})?$/.test(v); }
function validColor(v) { return /^0x[0-9A-Fa-f]{6}$/.test(v); }
function validColorList(v) { return /^0x[0-9A-Fa-f]{6}(\s*,\s*0x[0-9A-Fa-f]{6})*$/.test(v); }
function tidyColors(v) {
  return v.replace(/#/g, "0x").replace(/0X/g, "0x").replace(/\s*,\s*/g, ",").replace(/^,+|,+$/g, "");
}
// Returns "" when the value is fine, otherwise the message to show.
function problem(inp, v) {
  if (hasClass(inp, "num") && !validNum(v)) return "Whole numbers only - not saved.";
  if (hasClass(inp, "dec") && !validDec(v)) return "Numbers only (like -0.5 or 1) - not saved.";
  if (hasClass(inp, "color") && hasClass(inp, "opt") && v === "") return "";
  if (hasClass(inp, "color") && hasClass(inp, "list") && !validColorList(v)) return "Colours look like 0x60AA4A, with commas between several - not saved.";
  if (hasClass(inp, "color") && !hasClass(inp, "list") && !validColor(v)) return "Colours look like 0x60AA4A - not saved.";
  if (hasClass(inp, "pct") && Number(v) > 100) return "Percent must be 0 to 100 - not saved.";
  if (hasClass(inp, "url") && v !== "" && !/^https:\/\/((canary|ptb)\.)?(discord|discordapp)\.com\/api\/webhooks\/\S+$/.test(v))
    return "That isn't a Discord webhook link (https://discord.com/api/webhooks/...) - not saved.";
  return "";
}
function saveInput(inp) {
  var v = inp.value.replace(/^\s+|\s+$/g, "");
  if (hasClass(inp, "color")) v = tidyColors(v);
  var bad = problem(inp, v);
  if (bad) {
    addClass(inp, "bad");
    flash(bad, "bad");
    return;
  }
  delClass(inp, "bad");
  inp.value = v;
  if (v === inp.getAttribute("data-saved")) return;
  inp.setAttribute("data-saved", v);
  writeVal(inp, v);
  flash("Saved.");
  refreshKeys();
  refreshExtras();
}

// ---------- colour swatches and the shake search-area picture ----------
function refreshSwatches() {
  each(document.querySelectorAll("input.color"), function (inp) {
    var sw = inp.parentNode.querySelector(".swatch");
    if (!sw) return;
    var parts = tidyColors(inp.value.replace(/^\s+|\s+$/g, "")).split(","), html = "";
    each(parts, function (p) { if (validColor(p)) html += '<i style="background:#' + p.substr(2) + '"></i>'; });
    sw.innerHTML = html;
    sw.title = html ? "" : "no colour";
  });
}
function pctOf(key, def) {
  var el = document.querySelector('input[data-key="' + key + '"]');
  var n = el ? Number(el.value) : def;
  if (isNaN(n)) n = def;
  return Math.max(0, Math.min(100, n));
}
function refreshArea() {
  var box = $("areaBox");
  if (!box) return;
  var l = pctOf("ShakeAreaLeftPct", 21), r = pctOf("ShakeAreaRightPct", 79);
  var t = pctOf("ShakeAreaTopPct", 25), b = pctOf("ShakeAreaBottomPct", 88);
  if (r < l) { var x = l; l = r; r = x; }
  if (b < t) { var y = t; t = b; b = y; }
  box.style.left = l + "%"; box.style.width = (r - l) + "%";
  box.style.top = t + "%"; box.style.height = (b - t) + "%";
}
function refreshExtras() { refreshSwatches(); refreshArea(); }

// ---------- segmented choices (Normal | Perfect) and what they show ----------
var segVals = {};
function applyShows() {
  each(document.querySelectorAll("[data-show]"), function (el) {
    var p = el.getAttribute("data-show").split("=");
    if (segVals[p[0]] === p[1]) delClass(el, "hidden"); else addClass(el, "hidden");
  });
  applyLocks();
  layoutMinigame();
}

// =====================================================================================
// Minigame page: which cards a rod shows, which detection modes it allows, and the
// colour presets a rod fills in. Mirrors LayoutMinigame / RefreshControlModes /
// SpecialRodChanged and the Apply...Preset routines in Fisch_dick.ahk.
// =====================================================================================
function rodNow() { var s = $("rodSel"); return s ? s.value : "None"; }

function allowedModes(rod) {
  if (rod === "Noiseform") return ["Precision"];
  if (rod === "Darkheart" || rod === "Pinions Aria" || rod === "Lullaby" || rod === "Castbound" || rod === "Oppressor") return ["Lines"];
  if (rod === "Remembrance") return ["Lines", "Precision"];
  if (rod === "MiguRod" || rod === "Halibut Harpoon" || rod === "Tryhard Rod" || rod === "Stellarwave Melody") return ["Precision"];
  if (rod === "Requiem" || rod === "Bellona's Waraxe" || rod === "Dreambreaker" || rod === "Verdant Oath") return ["Lines", "Precision"];
  return ["Manual", "Precision", "Lines"];
}
function inList(list, v) { for (var i = 0; i < list.length; i++) if (list[i] === v) return true; return false; }

// Show only the detection modes this rod allows; switch to the first allowed one if needed.
function applyModes() {
  var seg = $("modeSeg");
  if (!seg) return;
  var ok = allowedModes(rodNow());
  each(seg.querySelectorAll("a"), function (a) {
    if (inList(ok, a.getAttribute("data-v"))) delClass(a, "gone"); else addClass(a, "gone");
  });
  if (!inList(ok, segVals.ControlMode)) {
    markSeg(seg, ok[0]);
    writeVal(seg, ok[0]);
  }
}

function minigameVisible() {
  var rod = rodNow(), mode = segVals.ControlMode, v = { mode: 1, barctl: 1, detcheck: 1 };
  if (rod === "Halibut Harpoon") v.halicol = 1;
  if (rod === "Remembrance") v.remem = 1;
  if (rod === "Pinions Aria") v.notes = 1;
  else if ((mode !== "Lines" || rod === "Remembrance") && rod !== "Tryhard Rod" && rod !== "Stellarwave Melody") v.colors = 1;
  if (rod === "Stellarwave Melody") { v.stellar = 1; v.swcol = 1; }
  if (rod === "Tryhard Rod") v.trycol = 1;
  if (rod === "Castbound") v.cbcol = 1;
  if (rod === "Requiem") v.reel = 1;
  if (mode === "Manual") v.manual = 1; else v.precision = 1;
  return v;
}
function layoutMinigame() {
  if (!$("rodSel")) return;
  var v = minigameVisible();
  each(document.querySelectorAll("[data-vis]"), function (el) {
    if (v[el.getAttribute("data-vis")]) delClass(el, "hidden"); else addClass(el, "hidden");
  });
}

// Set one setting by key: updates the box/switch/choice on screen and saves it.
function setField(key, val) {
  var el = document.querySelector('[data-key="' + key + '"]');
  if (!el) return;
  val = String(val);
  if (hasClass(el, "switch")) { if (isOn(el, val)) addClass(el, "on"); else delClass(el, "on"); }
  else if (hasClass(el, "seg")) markSeg(el, val);
  else { el.value = val; el.setAttribute("data-saved", val); delClass(el, "bad"); }
  writeVal(el, val);
}
function setFields(map) { for (var k in map) if (map.hasOwnProperty(k)) setField(k, map[k]); }
function fieldVal(key) { var el = document.querySelector('[data-key="' + key + '"]'); return el ? String(el.value) : ""; }

// A rod's own colours are put back to the defaults when you switch away from it.
var NO_ROD_SETS = [
  ["0x0C4125", "0x33A95F"], ["0x0D0B0B", "0x5D52A8"], ["0x434B5B", "0x67512C"],
  ["0xFFFFFF", "0x474747"], ["0xFFFFFF", "0xB5B5B5"],
  ["0xF9D9D4,0xFAD6CE,0xF9D4C7,0xF9D2C4,0xF8D0B7", "0xE9B681,0xE0A66F,0xD1935B"],
  ["0xCFCFCF,0xD6D6D6,0xBBBBBB", "0x8E8E8E,0x7D7D7D,0x2C211B,0x291E18"]
];
function resetRodColoursIfPreset() {
  var fish = fieldVal("FishColor").toUpperCase(), left = fieldVal("BarLeftColor").toUpperCase();
  for (var i = 0; i < NO_ROD_SETS.length; i++) {
    if (fish === NO_ROD_SETS[i][0].toUpperCase() && left === NO_ROD_SETS[i][1].toUpperCase()) {
      setFields({ FishColor: "0x434B5B", BarLeftColor: "0xF1F1F1", BarRightColor: "0xF1F1F1", ArrowColor: "0x848587",
                  BarColorTolerance: 3, FishBarColorTolerance: 3, ArrowColorTolerance: 3 });
      return;
    }
  }
}
function applyRemembrance(state) {
  if (state === "Departed") setFields({ BarLeftColor: "0x474747", BarRightColor: "0x474747", BarColorTolerance: 8 });
  else setFields({ BarLeftColor: "0xB5B5B5", BarRightColor: "0xB5B5B5", BarColorTolerance: 10 });
  setFields({ FishColor: "0xFFFFFF", FishBarColorTolerance: 10 });
  refreshExtras();
}
var ROD_PRESETS = {
  "Halibut Harpoon": { FishColor: "0x0D0B0B", BarLeftColor: "0x5D52A8", BarRightColor: "0x5D52A8", ArrowColor: "0x413A76",
                       BarColorTolerance: 3, FishBarColorTolerance: 3, ArrowColorTolerance: 3 },
  "Noiseform": { FishColor: "0x0C4125", BarLeftColor: "0x33A95F", BarRightColor: "0x2C894D", ArrowColor: "0x000000",
                 BarColorTolerance: 3, FishBarColorTolerance: 5, ArrowColorTolerance: 0,
                 Kp: 0.3, Kd: 0.3, VelocitySmoothing: 0.5, StoppingDistanceMultiplier: "5.0" },
  "MiguRod": { BarLeftColor: "0xE9B681,0xE0A66F,0xD1935B", BarRightColor: "0xE9B681,0xE0A66F,0xD1935B", BarColorTolerance: 14,
               FishColor: "0xF9D9D4,0xFAD6CE,0xF9D4C7,0xF9D2C4,0xF8D0B7", FishBarColorTolerance: 10 },
  "Oppressor": { BarLeftColor: "0x8E8E8E,0x7D7D7D,0x2C211B,0x291E18", BarRightColor: "0x8E8E8E,0x7D7D7D,0x2C211B,0x291E18",
                 BarColorTolerance: 8, FishColor: "0xCFCFCF,0xD6D6D6,0xBBBBBB", FishBarColorTolerance: 12 },
  "Verdant Oath": { FishColor: "0x434B5B", BarLeftColor: "0x67512C", BarRightColor: "0x65502D", ArrowColor: "0x848587",
                    BarColorTolerance: 3, FishBarColorTolerance: 12, ArrowColorTolerance: 0 }
};
var ROD_MODE = { "Requiem": "Lines", "Darkheart": "Lines", "Lullaby": "Lines", "Verdant Oath": "Lines", "Oppressor": "Lines",
  "Remembrance": "Lines", "MiguRod": "Precision", "Halibut Harpoon": "Precision", "Tryhard Rod": "Precision", "Stellarwave Melody": "Precision" };

function rodChanged() {
  var rod = rodNow();
  writeVal($("rodSel"), rod);
  if (ROD_MODE[rod]) setField("ControlMode", ROD_MODE[rod]);
  resetRodColoursIfPreset();
  if (ROD_PRESETS[rod]) setFields(ROD_PRESETS[rod]);
  if (rod === "Remembrance") applyRemembrance(segVals.RemembranceMode || "Living");
  applyModes();
  applyShows();
  refreshExtras();
  flash(ROD_PRESETS[rod] || rod === "Remembrance" ? "Saved - " + rod + " colours filled in." : "Saved.");
}

function restoreMinigameDefaults() {
  if (!window.confirm("Reset every minigame and rod setting (and the Perfect cast colours) to the defaults?\n\nThis can't be undone.")) return;
  var page = $("page-minigame");
  each(page.querySelectorAll("[data-key]"), function (el) { setField(el.getAttribute("data-key"), el.getAttribute("data-def") || ""); });
  setFields({ PerfectGreenColor: "0x60AA4A", PerfectWhiteColor: "0xFFFEF3" });
  $("rodSel").value = "None";
  applyModes();
  applyShows();
  refreshExtras();
  refreshChecks();
  flash("Minigame settings reset to the defaults.");
}

// =====================================================================================
// Utilities page: on/off cards, the camera-mode lock, Auto Totem event rules
// (TotemPickClash / TotemSelSanitize / RefreshTotemKeys in Fisch_dick.ahk) and Keeper spots.
// =====================================================================================
function switchOn(key) { var el = document.querySelector('.switch[data-key="' + key + '"]'); return el ? hasClass(el, "on") : false; }

function refreshUtil() {
  each(document.querySelectorAll(".card.util"), function (card) {
    var sw = card.querySelector(".head-switch");
    if (sw && hasClass(sw, "on")) addClass(card, "util-on"); else delClass(card, "util-on");
  });
  var row = $("rowCamMode");
  if (!row) return;
  var sw = row.querySelector(".switch"), inp = row.querySelector("input");
  if (switchOn("TotemAuto") || switchOn("AquariumAuto") || switchOn("KeeperAuto")) {
    addClass(row, "locked"); sw.setAttribute("data-locked", "1"); inp.disabled = true;
  } else {
    delClass(row, "locked"); sw.removeAttribute("data-locked"); inp.disabled = false;
  }
}

var TOTEM_OPTS = ["None", "Day", "Night", "Clearcast", "Aurora", "Starfall", "Eclipse", "Tempest", "Windset", "Smokescreen", "Shiny", "Sparkling", "Mutation"];
function tNeedsTime(n) { if (n === "Day" || n === "Night") return n; if (n === "Aurora" || n === "Starfall") return "Night"; if (n === "Eclipse") return "Day"; return ""; }
function tWeatherState(n) { return n === "Clearcast" || n === "Tempest" || n === "Windset" || n === "Smokescreen"; }
function tGroup(n) { return (n === "Shiny" || n === "Sparkling" || n === "Mutation") ? "shiny" : ""; }
function tClash(a, b, hard) {
  if (!a || !b || a === "None" || b === "None") return false;
  if (a === b) return true;
  var ta = tNeedsTime(a), tb = tNeedsTime(b);
  if (ta && tb) return ta !== tb || (!hard && (a === ta || b === tb));
  if (tWeatherState(a) && tWeatherState(b)) return true;
  var ga = tGroup(a);
  return ga !== "" && ga === tGroup(b);
}
function tTimeCovered(v, w1, w2) {
  if (v !== "Day" && v !== "Night") return false;
  return (w1 !== v && tNeedsTime(w1) === v) || (w2 !== v && tNeedsTime(w2) === v);
}
function tSanitize(s) {
  for (var i = 0; i < 3; i++) if (!s[i] || !inList(TOTEM_OPTS, s[i])) s[i] = "None";
  if (tClash(s[0], s[1], true)) s[1] = "None";
  if (tClash(s[0], s[2], true) || tClash(s[1], s[2], true)) s[2] = "None";
  if (tTimeCovered(s[0], s[1], s[2])) s[0] = "None";
  if (tTimeCovered(s[1], s[0], s[2])) s[1] = "None";
  if (tTimeCovered(s[2], s[0], s[1])) s[2] = "None";
  if (tClash(s[0], s[1])) s[1] = "None";
  if (tClash(s[0], s[2]) || tClash(s[1], s[2])) s[2] = "None";
  return s;
}
function totemSels() { return document.querySelectorAll("select.tsel"); }
function fillTotemLists(s) {
  each(totemSels(), function (sel, k) {
    sel.innerHTML = "";
    each(TOTEM_OPTS, function (opt) {
      for (var j = 0; j < 3; j++) if (j !== k && tClash(opt, s[j])) return;
      var o = document.createElement("option");
      o.value = opt; o.text = opt;
      if (opt === s[k]) o.selected = true;
      sel.appendChild(o);
    });
  });
  // show only the hotbar keys the chosen events need (Sundial first, then Clearcast, then the rest)
  var need = {};
  each(s, function (n) {
    if (n === "None") return;
    if (n === "Day" || n === "Night") { need.Sundial = 1; return; }
    need[n] = 1;
    if (n === "Aurora" || n === "Starfall" || n === "Eclipse") need.Sundial = 1;
  });
  var any = false, box = $("totemKeys");
  each(box.querySelectorAll("[data-totem]"), function (r) {
    if (need[r.getAttribute("data-totem")]) { delClass(r, "hidden"); any = true; } else addClass(r, "hidden");
  });
  if (any) addClass($("totemNoKeys"), "hidden"); else delClass($("totemNoKeys"), "hidden");
}
function loadTotems() {
  var sels = totemSels();
  if (!sels.length) return;
  var s = [], before = [];
  each(sels, function (sel) { var v = readVal(sel); s.push(v); before.push(v); });
  s = tSanitize(s);
  each(sels, function (sel, k) { if (s[k] !== before[k]) writeVal(sel, s[k]); });
  fillTotemLists(s);
}
function setupTotems() {
  each(totemSels(), function (sel) {
    sel.onchange = function () {
      var s = [];
      each(totemSels(), function (x) { s.push(x.value); });
      s = tSanitize(s);
      each(totemSels(), function (x, k) { writeVal(x, s[k]); });
      fillTotemLists(s);
      flash("Saved.");
    };
  });
}

function refreshSpots() {
  if (!$("spotEnchant")) return;
  var spot = function (xk, yk) {
    var x = Math.round(Number(ahk.Get("settings", "Keeper", xk, "0"))), y = Math.round(Number(ahk.Get("settings", "Keeper", yk, "0")));
    return (x > 0 && y > 0) ? "Set to " + x + ", " + y : "Not set - found by looking";
  };
  $("spotEnchant").innerHTML = spot("KeeperEnchantX", "KeeperEnchantY");
  $("spotConfirm").innerHTML = spot("KeeperConfirmX", "KeeperConfirmY");
}
function setupUtilities() {
  if (!$("totemKeys")) return;
  setupTotems();
  $("clrEnchant").onclick = function () { ahk.Set("settings", "Keeper", "KeeperEnchantX", "0"); ahk.Set("settings", "Keeper", "KeeperEnchantY", "0"); refreshSpots(); flash("Enchant Rod position cleared."); };
  $("clrConfirm").onclick = function () { ahk.Set("settings", "Keeper", "KeeperConfirmX", "0"); ahk.Set("settings", "Keeper", "KeeperConfirmY", "0"); refreshSpots(); flash("Confirm position cleared."); };
  each(document.querySelectorAll(".btn.pick"), function (b) {
    b.onclick = function () {
      if (!connected()) { flash("Picking a position isn't connected in the preview.", "bad"); return; }
      ahk.PickSpot(b.getAttribute("data-which"));
    };
  });
  $("btnWhTest").onclick = function () {
    if (!connected()) { flash("Sending a test message isn't connected in the preview.", "bad"); return; }
    ahk.WebhookTest();
    flash("Sending a test message...");
  };
}

function loadRod() {
  var s = $("rodSel");
  if (!s) return;
  var v = readVal(s), found = false;
  each(s.options, function (o) { if (o.text === v) { o.selected = true; found = true; } });
  if (!found) s.value = "None";
  applyModes();
}
function setupMinigame() {
  if (!$("rodSel")) return;
  $("rodSel").onchange = rodChanged;
  $("btnMgDefaults").onclick = restoreMinigameDefaults;
  $("btnDetTest").onclick = function () {
    if (!connected()) { flash("Test detection isn't connected in the preview.", "bad"); return; }
    ahk.DetTest();
    setTimeout(refreshStatus, 200);
  };
  each(document.querySelectorAll(".cmgr"), function (b) { b.onclick = openColorManager; });
}
function markSeg(seg, v) {
  var found = false;
  each(seg.querySelectorAll("a"), function (a) {
    if (a.getAttribute("data-v") === v) { addClass(a, "active"); found = true; } else delClass(a, "active");
  });
  if (!found) { v = seg.getAttribute("data-def"); markSeg(seg, v); return; }
  segVals[seg.getAttribute("data-key")] = v;
}
function loadSegs() {
  each(document.querySelectorAll(".seg"), function (seg) { markSeg(seg, readVal(seg)); });
  loadRod();
  applyShows();
}
function setupSegs() {
  each(document.querySelectorAll(".seg"), function (seg) {
    each(seg.querySelectorAll("a"), function (a) {
      a.onclick = function () {
        var v = a.getAttribute("data-v");
        if (segVals[seg.getAttribute("data-key")] === v) return;
        markSeg(seg, v);
        writeVal(seg, v);
        if (seg.getAttribute("data-key") === "RemembranceMode") applyRemembrance(v);
        applyShows();
        flash("Saved.");
      };
    });
  });
}

// Perfect cast needs the camera left alone, so auto-zoom is forced off and locked.
function applyLocks() {
  var row = $("rowZoom");
  if (!row) return;
  var sw = row.querySelector(".switch"), inp = row.querySelector("input");
  if (segVals.CastMode === "Perfect") {
    addClass(row, "locked");
    sw.setAttribute("data-locked", "1");
    inp.disabled = true;
    if (hasClass(sw, "on")) { delClass(sw, "on"); writeVal(sw, "false"); refreshChecks(); }
  } else {
    delClass(row, "locked");
    sw.removeAttribute("data-locked");
    inp.disabled = false;
  }
}

// ---------- "?" tooltips ----------
function escHtml(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function setupTips() {
  var tip = $("tip");
  each(document.querySelectorAll(".hint"), function (h) {
    h.onmouseover = function () {
      tip.innerHTML = escHtml(h.getAttribute("data-tip") || "").replace(/\n/g, "<br>");
      tip.style.display = "block";
      var r = h.getBoundingClientRect();
      var x = r.right + 10, y = r.top - 6;
      var w = tip.offsetWidth, ht = tip.offsetHeight;
      var vw = document.documentElement.clientWidth, vh = document.documentElement.clientHeight;
      if (x + w > vw - 8) x = Math.max(8, r.left - w - 10);
      if (y + ht > vh - 8) y = Math.max(8, vh - ht - 8);
      tip.style.left = x + "px"; tip.style.top = y + "px";
    };
    h.onmouseout = function () { tip.style.display = "none"; };
  });
  $("content").onscroll = function () { tip.style.display = "none"; };
}

// Key boxes: press a key to set it (Esc cancels).
var KEYNAMES = { 8: "Backspace", 9: "Tab", 13: "Enter", 32: "Space", 45: "Insert", 46: "Delete", 36: "Home", 35: "End",
  33: "PgUp", 34: "PgDn", 37: "Left", 38: "Up", 39: "Right", 40: "Down", 186: ";", 187: "=", 188: ",", 189: "-",
  190: ".", 191: "/", 192: "`", 219: "[", 220: "\\", 221: "]", 222: "'" };
function keyName(code) {
  if (code >= 65 && code <= 90) return String.fromCharCode(code).toLowerCase();
  if (code >= 48 && code <= 57) return String.fromCharCode(code);
  if (code >= 96 && code <= 105) return "Numpad" + (code - 96);
  if (code >= 112 && code <= 135) return "F" + (code - 111);
  return KEYNAMES[code] || "";
}
function setupInputs() {
  each(document.querySelectorAll("input.input"), function (inp) {
    inp.setAttribute("data-saved", inp.value);
    if (hasClass(inp, "key-input")) {
      inp.setAttribute("readOnly", "readOnly");
      inp.onfocus = function () { inp.setAttribute("data-old", inp.value); inp.value = "press a key"; };
      inp.onblur = function () { if (inp.value === "press a key") inp.value = inp.getAttribute("data-old"); };
      inp.onkeydown = function (e) {
        e = e || window.event;
        var code = e.keyCode;
        if (code === 16 || code === 17 || code === 18) return false; // lone Shift/Ctrl/Alt
        if (code === 27) { inp.value = inp.getAttribute("data-old"); inp.blur(); return false; }
        if ((code === 8 || code === 46) && inp.getAttribute("data-def") === "") {  // optional keys: Backspace/Delete clears
          inp.value = ""; saveInput(inp); inp.blur(); return false;
        }
        var name = keyName(code);
        if (!name) { flash("That key can't be used.", "bad"); return false; }
        inp.value = name;
        saveInput(inp);
        inp.blur();
        return false;
      };
    } else {
      inp.onchange = function () { saveInput(inp); };
      inp.onblur = function () { saveInput(inp); };
      inp.onkeyup = function (e) {
        e = e || window.event;
        if (e.keyCode === 13) { saveInput(inp); inp.blur(); return; }
        var v = inp.value.replace(/^\s+|\s+$/g, "");
        if (hasClass(inp, "color")) v = tidyColors(v);
        if (v === "" || !problem(inp, v)) delClass(inp, "bad"); else addClass(inp, "bad");
        refreshExtras();
      };
    }
  });
}

// ---------- left panel ----------
function refreshKeys() {
  $("keyStart").innerHTML = String(ahk.Get("settings", "Hotkeys", "StartStop", "p")).toUpperCase();
  $("keyReload").innerHTML = String(ahk.Get("settings", "Hotkeys", "Reload", "o")).toUpperCase();
  $("keyExit").innerHTML = String(ahk.Get("settings", "Hotkeys", "Exit", "m")).toUpperCase();
  // the About page shows the same keys and the active profile
  if ($("aboutKeyStart")) {
    $("aboutKeyStart").innerHTML = $("aboutKeyStart2").innerHTML = $("keyStart").innerHTML;
    $("aboutKeyReload").innerHTML = $("keyReload").innerHTML;
    $("aboutKeyExit").innerHTML = $("keyExit").innerHTML;
    $("aboutProfile").innerHTML = escHtml(String(ahk.ActiveProfile()));
  }
}
function checkRow(label, on, onText, offText) {
  return '<div class="check"><span>' + label + '</span><span class="' + (on ? "on" : "off") + '">' + (on ? onText : offText) + '</span></div>';
}
function refreshChecks() {
  var g = function (k, d) { return isOn(null, ahk.Get("profile", "General", k, d)); };
  var html = "";
  html += checkRow("Roblox", Number(ahk.RobloxOpen()) === 1, "found", "not open");
  html += checkRow("Lower graphics", g("AutoLowerGraphics", "true"), "on", "off");
  html += checkRow("Camera mode", g("AutoEnableCameraMode", "true"), "on", "off");
  html += checkRow("Look down", g("AutoLookDownCamera", "true"), "on", "off");
  $("checks").innerHTML = html;
}
function loadProfiles() {
  var sel = $("profile");
  var names = String(ahk.Profiles()).split("|");
  var active = String(ahk.ActiveProfile());
  sel.innerHTML = "";
  each(names, function (n) {
    if (!n) return;
    var o = document.createElement("option");
    o.value = n; o.text = n;
    if (n === active) o.selected = true;
    sel.appendChild(o);
  });
  sel.onchange = function () {
    closeProfEdit();
    ahk.SetProfile(sel.value);
    loadAll();
    flash("Profile: " + sel.value);
  };
}

// ---------- new / rename profile (small box under the profile list) ----------
var profMode = "";
function openProfEdit(mode) {
  profMode = mode;
  var box = $("profEdit"), name = $("profName");
  if (mode === "rename") {
    var cur = String(ahk.ActiveProfile());
    if (cur.toLowerCase() === "default") {
      flash("Default can't be renamed - the macro always keeps it. Use + New to make your own.", "bad");
      return;
    }
    $("profEditTitle").innerHTML = "Rename profile";
    addClass($("profCopyRow"), "hidden");
    name.value = cur;
  } else {
    $("profEditTitle").innerHTML = "New profile";
    delClass($("profCopyRow"), "hidden");
    name.value = "";
  }
  delClass(box, "hidden");
  name.focus();
  name.select();
}
function closeProfEdit() {
  profMode = "";
  addClass($("profEdit"), "hidden");
}
function saveProfEdit() {
  var name = $("profName").value.replace(/^\s+|\s+$/g, "");
  if (name === "") { flash("Type a name first.", "bad"); return; }
  if (/[\\\/:*?"<>|]/.test(name)) { flash("Profile names can't contain \\ / : * ? \" < > |", "bad"); return; }
  var err = profMode === "rename"
    ? String(ahk.RenameProfile(name))
    : String(ahk.NewProfile(name, hasClass($("profCopy"), "on") ? 1 : 0));
  if (err !== "") { flash(err, "bad"); return; }
  var what = profMode === "rename" ? "Renamed to " : "Made profile ";
  closeProfEdit();
  loadProfiles();
  loadAll();
  flash(what + name + ".");
}
function setupProfEdit() {
  $("profNew").onclick = function () { openProfEdit("new"); };
  $("profRename").onclick = function () { openProfEdit("rename"); };
  $("profCancel").onclick = closeProfEdit;
  $("profSave").onclick = saveProfEdit;
  $("profCopyRow").onclick = function () {
    var s = $("profCopy");
    if (hasClass(s, "on")) delClass(s, "on"); else addClass(s, "on");
    return false;
  };
  $("profName").onkeydown = function (e) {
    e = e || window.event;
    if (e.keyCode === 13) { saveProfEdit(); return false; }
    if (e.keyCode === 27) { closeProfEdit(); return false; }
  };
}

// ---------- minigame running: the macro calls setBusy(1/0); while busy the page does not poll it ----------
var busy = false;
function setBusy(b) {
  busy = !!b;
  if (!busy) { refreshState(); refreshStatus(); }   // catch up right after each fish
}

// ---------- live state from the macro (Start button + stats) ----------
var isConnected = null;
function connected() {
  if (isConnected === null) { try { isConnected = String(ahk.Mode()) === "macro"; } catch (e) { isConnected = false; } }
  return isConnected;
}
var lastState = "";
function refreshState() {
  if (!connected()) { $("statState").innerHTML = "Preview"; return; }
  var p = String(ahk.State()).split("|"), st = p[0], secs = Number(p[2]) || 0;
  $("statCatches").innerHTML = p[1] || "0";
  var h = Math.floor(secs / 3600), m = Math.floor(secs / 60) % 60, s = secs % 60;
  $("statTime").innerHTML = (h ? h + ":" + (m < 10 ? "0" : "") : "") + m + ":" + (s < 10 ? "0" : "") + s;
  if (st === lastState) return;
  lastState = st;
  var key = $("keyStart").innerHTML;
  if (st === "running") {
    $("startText").innerHTML = "&#9632;&nbsp; Stop"; addClass($("btnStart"), "stop");
    $("statState").innerHTML = "Running";
  } else if (st === "ready") {
    $("startText").innerHTML = "&#9654;&nbsp; Start"; delClass($("btnStart"), "stop");
    $("statState").innerHTML = "Ready - press " + key;
  } else {
    $("startText").innerHTML = "&#9654;&nbsp; Start"; delClass($("btnStart"), "stop");
    $("statState").innerHTML = "Idle";
  }
}

// =====================================================================================
// Color Manager page - same targets, labels, hints and list rules as the classic one
// (CMApplyTargets / CMTargetLabel / CMTargetHint / ColListAdd in macro.ahk).
// =====================================================================================
var CM_LABEL = { FishColor: "Fish line", BarLeftColor: "Bar - left end", BarRightColor: "Bar - right end", ArrowColor: "Bar arrow",
  NoteColor: "Falling note", PerfectGreenColor: "Cast bar - green", PerfectWhiteColor: "Cast bar - white",
  TryhardBarColors: "Tryhard bar", TryhardFishColors: "Tryhard fish", TryhardTrackColors: "Tryhard track",
  CastboundBarColors: "Castbound bar", CastboundFishColors: "Castbound sword", CastboundTrackColors: "Castbound track",
  StellarBarColors: "Stellarwave bar", StellarFishColors: "Stellarwave fish", StellarHeadColors: "Stellarwave fish head" };
var CM_HINT = { FishColor: "The thin marker that slides along the bar - the fish you are chasing.",
  BarLeftColor: "The LEFT end of the reeling bar. Add every shade it takes if the bar changes colour as it fills.",
  BarRightColor: "The RIGHT end of the reeling bar. Add every shade it takes if the bar changes colour as it fills.",
  ArrowColor: "The small arrow drawn inside the reeling bar.",
  NoteColor: "A falling note. Pinions Aria only.",
  PerfectGreenColor: "The green perfect-cast marker on the cast power bar.",
  PerfectWhiteColor: "The white fill of the cast power bar.",
  TryhardBarColors: "Only if the bar is never picked up. Click the bar while the fish is inside it (bright red) and while it is outside (dark red).",
  TryhardFishColors: "Only if the fish is never found. Click the dark marker that sticks out above the bar.",
  TryhardTrackColors: "Only if the bar is still not found. Click the dark red track beside the bar.",
  CastboundBarColors: "Only helps if the bar looks very dark on your screen. Pick the track and the sword first.",
  CastboundFishColors: "Only if the fish is never found. Click the purple sword marker. 0x5522A3 is the normal colour and changes nothing.",
  CastboundTrackColors: "Only if the minigame is never detected. Click the purple track the bar slides on.",
  StellarBarColors: "The thin dark purple frame around the bar, not the colourful inside. 0x55446D is the normal colour.",
  StellarFishColors: "The light blue line of the fish on the bar. 0xAFDAE8 is the normal colour.",
  StellarHeadColors: "The white note head of the fish, just above the bar. 0xFFFFFF is the normal colour." };
function cmSection(k) {
  if (k === "PerfectGreenColor" || k === "PerfectWhiteColor") return "Cast";
  if (/^(Tryhard|Castbound|Stellar)/.test(k)) return "Rods";
  return "Minigame";
}
function cmKeys() {
  var rod = rodNow();
  if (rod === "Tryhard Rod") return ["TryhardFishColors", "TryhardBarColors", "TryhardTrackColors", "ArrowColor", "NoteColor", "PerfectGreenColor", "PerfectWhiteColor"];
  if (rod === "Castbound") return ["CastboundFishColors", "CastboundBarColors", "CastboundTrackColors", "ArrowColor", "NoteColor", "PerfectGreenColor", "PerfectWhiteColor"];
  if (rod === "Stellarwave Melody") return ["StellarBarColors", "StellarFishColors", "StellarHeadColors", "PerfectGreenColor", "PerfectWhiteColor"];
  return ["FishColor", "BarLeftColor", "BarRightColor", "ArrowColor", "NoteColor", "PerfectGreenColor", "PerfectWhiteColor"];
}
var cmSel = "FishColor";
// a colour list as an array of "0xRRGGBB" (accepts 0x, #, commas, spaces)
function cmParse(s) {
  var out = [], seen = {};
  each(String(s || "").split(/[\s,;|]+/), function (p) {
    p = p.replace(/^#/, "").replace(/^0x/i, "");
    if (!/^[0-9A-Fa-f]{6}$/.test(p)) return;
    p = "0x" + p.toUpperCase();
    if (!seen[p] && out.length < 9) { seen[p] = 1; out.push(p); }
  });
  return out;
}
function cmGet(k) {
  var el = document.querySelector('[data-key="' + k + '"]');
  return String(ahk.Get("profile", cmSection(k), k, el ? (el.getAttribute("data-def") || "") : ""));
}
function cmSet(k, arr) {
  var v = arr.join(", ");
  ahk.Set("profile", cmSection(k), k, v);
  var el = document.querySelector('input[data-key="' + k + '"]');   // keep the Cast / Minigame boxes in step
  if (el) { el.value = v; el.setAttribute("data-saved", v); delClass(el, "bad"); }
  refreshExtras();
  cmRender();
}
function cmRender() {
  if (!$("cmTargets")) return;
  var keys = cmKeys();
  if (!inList(keys, cmSel)) cmSel = keys[0];
  var html = "";
  each(keys, function (k) {
    var list = cmParse(cmGet(k));
    html += '<div class="cm-item' + (k === cmSel ? " active" : "") + '" data-k="' + k + '"><span>'
      + '<span class="cm-dot" style="background:' + (list.length ? "#" + list[0].substr(2) : "transparent") + '"></span>'
      + escHtml(CM_LABEL[k] || k) + '</span><span class="cm-count' + (list.length ? "" : " none") + '">'
      + (list.length ? list.length : "not set") + "</span></div>";
  });
  $("cmTargets").innerHTML = html;
  each($("cmTargets").querySelectorAll(".cm-item"), function (it) {
    it.onclick = function () { cmSel = it.getAttribute("data-k"); cmRender(); };
  });
  $("cmTitle").innerHTML = escHtml(CM_LABEL[cmSel] || cmSel);
  $("cmHint").innerHTML = escHtml(CM_HINT[cmSel] || "");
  var list = cmParse(cmGet(cmSel)), rows = "";
  each(list, function (hx, i) {
    rows += '<div class="cm-row"><span class="cm-sw" style="background:#' + hx.substr(2) + '"></span>'
      + '<span class="cm-hexval">' + hx + (i === 0 ? "<small>main colour</small>" : "") + "</span>"
      + '<span class="cm-del" data-i="' + i + '" title="Remove this colour">&#10005;</span></div>';
  });
  $("cmRows").innerHTML = rows || '<div class="cm-empty">Nothing picked for this one yet. Press <b>Pick from screen</b> and click the colour in game.</div>';
  each($("cmRows").querySelectorAll(".cm-del"), function (d) {
    d.onclick = function () {
      var l = cmParse(cmGet(cmSel));
      l.splice(Number(d.getAttribute("data-i")), 1);
      cmSet(cmSel, l);
      flash("Colour removed.");
    };
  });
  var bar = cmSel === "BarLeftColor" || cmSel === "BarRightColor";
  if (bar) {
    delClass($("cmCopy"), "hidden");
    $("cmCopy").innerHTML = "Copy this list to " + (cmSel === "BarLeftColor" ? "Bar - right end" : "Bar - left end");
  } else addClass($("cmCopy"), "hidden");
}
// open the page; key (optional) picks which colour is shown first
function openColors(key) {
  if (key) cmSel = key;
  else if (connected()) { var s = String(ahk.CMSelected()); if (s) cmSel = s; }
  showPage("colors");
  each(document.querySelectorAll(".tab"), function (t) { delClass(t, "active"); });
  cmRender();
}
function openColorManager() {
  // the page buttons open the colour that belongs to their card
  var el = this, key = "", map = { colors: "FishColor", notes: "NoteColor", trycol: "TryhardFishColors", cbcol: "CastboundFishColors", swcol: "StellarBarColors" };
  while (el && el.getAttribute) {
    var v = el.getAttribute("data-vis");
    if (v && map[v]) { key = map[v]; break; }
    if (el.id === "page-cast") { key = "PerfectGreenColor"; break; }
    el = el.parentNode;
  }
  openColors(key);
}
function setupColors() {
  $("cmPick").onclick = function () {
    if (!connected()) { flash("Picking from the screen only works in Amethyst itself.", "bad"); return; }
    ahk.CMPick(cmSel);
  };
  var add = function () {
    var got = cmParse($("cmHex").value);
    if (!got.length) { flash("Colours look like 0xF1F1F1 (six hex digits).", "bad"); return; }
    var l = cmParse(cmGet(cmSel));
    if (inList(l, got[0])) { flash(got[0] + " is already in this list.", "bad"); return; }
    if (l.length >= 9) { flash("A list holds up to 9 colours - remove one first.", "bad"); return; }
    l.push(got[0]);
    $("cmHex").value = "";
    cmSet(cmSel, l);
    flash("Added " + got[0] + ".");
  };
  $("cmAdd").onclick = add;
  $("cmHex").onkeydown = function (e) { e = e || window.event; if (e.keyCode === 13) { add(); return false; } };
  $("cmClear").onclick = function () {
    if (!window.confirm("Clear every colour in " + (CM_LABEL[cmSel] || cmSel) + "?")) return;
    cmSet(cmSel, []);
    flash("List cleared.");
  };
  $("cmCopy").onclick = function () {
    var other = cmSel === "BarLeftColor" ? "BarRightColor" : "BarLeftColor";
    cmSet(other, cmParse(cmGet(cmSel)));
    flash("Copied to " + CM_LABEL[other] + ".");
  };
  cmRender();
}

// Utilities status lines + the detection test line, from the macro once a second.
var lastStatus = "";
function setLine(id, text, fallback) {
  var el = $(id);
  if (el) el.innerHTML = escHtml(text || fallback).replace(/\n/g, "<br>");
}
function refreshStatus() {
  if (!connected()) return;
  var raw = String(ahk.Status());
  if (raw === lastStatus) return;
  lastStatus = raw;
  var p = raw.split(String.fromCharCode(1));
  setLine("statusTotem", p[0], "Auto Totem is off.");
  setLine("statusAq", p[1], "Off.");
  setLine("statusKb", p[2], "Off.");
  var testing = p[3] === "1";
  $("btnDetTest").innerHTML = testing ? "&#9632;&nbsp; Stop test" : "&#9654;&nbsp; Test";
  setLine("detOut", p[4], testing ? "Watching..." : "Not running.");
}

function loadAll() {
  if (connected() && hasClass($("page-colors"), "active")) { var s = String(ahk.CMSelected()); if (s) cmSel = s; }
  loadSwitches();
  loadInputs();
  each(document.querySelectorAll("input.input"), function (inp) { inp.setAttribute("data-saved", inp.value); });
  loadSegs();
  loadTotems();
  refreshSpots();
  refreshUtil();
  refreshExtras();
  refreshKeys();
  refreshChecks();
  cmRender();                         // the Color Manager page (after a pick or a profile switch)
}

function init() {
  each(document.querySelectorAll(".tab"), function (t) {
    t.onclick = function () { showPage(t.getAttribute("data-page")); };
  });
  loadProfiles();
  buildUpdateLog();                   // before setupCards, so its cards fold like the others
  setupCards();
  loadAll();
  setupSwitches();
  setupInputs();
  setupSegs();
  setupTips();
  setupMinigame();
  setupUtilities();
  setupProfEdit();
  setupScrollbar();
  setupUpdate();
  setupColors();
  setupReadThis();
  $("btnColorMgr").onclick = openColorManager;
  if (connected()) setInterval(function () { if (!busy) refreshStatus(); }, 1000);
  refreshStatus();
  $("btnStart").onclick = function () {
    if (!connected()) { flash("Start isn't connected in the preview - run Fisch_dick.ahk instead.", "bad"); return; }
    if (!readThisAccepted()) { showReadThis(false); return; }
    ahk.Start();
    setTimeout(refreshState, 150);
  };
  if (connected()) setInterval(function () { if (!busy) refreshState(); }, 600);
  refreshState();
  $("btnReload").onclick = function () { ahk.Reload(); };
  $("btnExit").onclick = function () { ahk.Exit(); };
  setInterval(function () { if (!busy) refreshChecks(); }, 2000);
  // stop text selection / right-click menu outside the boxes
  document.onselectstart = function (e) { e = e || window.event; var t = e.target || e.srcElement; return t.tagName === "INPUT"; };
  document.oncontextmenu = function () { return false; };
}

// ---------- version + updates (About page row and the left-panel banner) ----------
var lastUpd = "";
function refreshUpdate() {
  if (!connected()) return;
  var st = String(ahk.UpdateState());
  if (st === lastUpd) return;
  lastUpd = st;
  var p = st.split("|"), kind = p[0], info = p[1] || "", btn = $("btnUpdate"), txt = $("updText");
  btn.disabled = false;
  addClass($("updBanner"), "hidden");
  delClass(btn, "primary");
  setUpdateText(kind, info, btn, txt);
}
function setUpdateText(kind, info, btn, txt) {
  if (kind === "available") {
    btn.innerHTML = "Update to v" + escHtml(info);
    addClass(btn, "primary");
    $("updBannerVer").innerHTML = "v" + escHtml(info);
    delClass($("updBanner"), "hidden");
    txt.innerHTML = "Version " + escHtml(info) + " is ready. Amethyst restarts to install it.";
  } else if (kind === "checking") {
    btn.innerHTML = "Checking..."; btn.disabled = true; txt.innerHTML = "Looking for a new version...";
  } else if (kind === "downloading" || kind === "installing" || kind === "restarting") {
    btn.innerHTML = "Updating..."; btn.disabled = true;
    txt.innerHTML = kind === "downloading" ? "Downloading the update..." : (kind === "installing" ? "Installing..." : "Restarting...");
  } else if (kind === "uptodate") {
    btn.innerHTML = "Check for updates"; txt.innerHTML = "You have the newest version.";
  } else if (kind === "notset") {
    btn.innerHTML = "Check for updates"; txt.innerHTML = "Updates are not set up yet (gui\\update.ini).";
  } else if (kind === "error") {
    btn.innerHTML = "Try again"; txt.innerHTML = '<span class="upd-err">' + escHtml(info) + "</span>";
  } else {
    btn.innerHTML = "Check for updates"; txt.innerHTML = "Not checked yet.";
  }
}
function setupUpdate() {
  if (connected()) {
    var v = String(ahk.Version());
    $("verSide").innerHTML = "v" + escHtml(v);
    $("verAbout").innerHTML = escHtml(v) + " (ALPHA)";
  }
  $("updBanner").onclick = function () { showPage("about"); };
  $("btnUpdate").onclick = function () {
    if (!connected()) { flash("Updates only work in Amethyst itself, not the preview.", "bad"); return; }
    var p = String(ahk.UpdateState()).split("|");
    if (p[0] === "available") {
      if (!window.confirm("Update Amethyst to version " + p[1] + "?\n\nIt closes, installs the update and opens again. Your settings and profiles are kept.")) return;
      ahk.UpdateInstall();
    } else {
      ahk.UpdateCheck();
    }
    setTimeout(refreshUpdate, 150);
  };
  if (connected()) setInterval(function () { if (!busy) refreshUpdate(); }, 800);
}

// ---------- "Before you start" (setup rules + accept, unlocks Start) ----------
function readThisAccepted() { return String(ahk.Get("settings", "GUI", "ReadThisAccepted", "0")) === "1"; }
function showReadThis(review) {
  var acc = readThisAccepted();
  if (acc) addClass($("rtAccept"), "on"); else delClass($("rtAccept"), "on");
  $("rtContinue").disabled = !acc;
  if (review && acc) delClass($("rtClose"), "hidden"); else addClass($("rtClose"), "hidden");
  delClass($("readThis"), "hidden");
  $("readThis").scrollTop = 0;
}
function setupReadThis() {
  $("rtAcceptRow").onclick = function () {
    var s = $("rtAccept");
    if (hasClass(s, "on")) delClass(s, "on"); else addClass(s, "on");
    $("rtContinue").disabled = !hasClass(s, "on");
    return false;
  };
  $("rtContinue").onclick = function () {
    if (!hasClass($("rtAccept"), "on")) return;
    if (!readThisAccepted()) ahk.Set("settings", "GUI", "ReadThisAccepted", "1");
    addClass($("readThis"), "hidden");
    flash("All set - press Start when Roblox is open.");
  };
  $("rtClose").onclick = function () { addClass($("readThis"), "hidden"); };
  $("btnShowRules").onclick = function () { showReadThis(true); };
  if (!readThisAccepted()) showReadThis(false);
}

// ---------- Update log tab: one folding card per version, newest open ----------
function buildUpdateLog() {
  if (!connected()) return;
  var raw = String(ahk.VersionLog()), cur = String(ahk.Version()), html = "";
  each(raw.split(String.fromCharCode(3)), function (block, k) {
    if (!block) return;
    var p = block.split(String.fromCharCode(2)), title = p[0], notes = (p[1] || "").split(String.fromCharCode(1));
    var num = title.replace(/^Version\s*/i, ""), isCur = num === cur;
    html += '<div class="card log-card' + (k > 0 ? '" data-start-collapsed="1"' : '"') + '>'
      + '<div class="card-head"><span class="chev">&#9662;</span>Version ' + escHtml(num)
      + (isCur ? '<span class="head-tag">installed</span>' : (k === 0 ? '<span class="head-tag">newest</span>' : ''))
      + '</div><div class="card-body tips">';
    each(notes, function (n) { if (n) html += "<div>" + escHtml(n) + "</div>"; });
    html += "</div></div>";
  });
  if (html) $("logList").innerHTML = html;
}

// ---------- rounded scroll bar (the real one is hidden by CSS) ----------
function setupScrollbar() {
  var c = $("content"), bar = $("sbar"), th = $("sthumb"), pad = 6, dragY = -1, dragTop = 0;
  function sizes() {
    var trackH = c.clientHeight - 2 * pad, sh = c.scrollHeight, ch = c.clientHeight;
    var h = Math.max(32, Math.round(trackH * ch / Math.max(sh, 1)));
    return { trackH: trackH, sh: sh, ch: ch, h: h };
  }
  function update() {
    var z = sizes();
    if (z.sh <= z.ch + 1) { bar.style.display = "none"; return; }
    bar.style.display = "block";
    bar.style.top = (c.offsetTop + pad) + "px";
    bar.style.height = z.trackH + "px";
    th.style.height = z.h + "px";
    th.style.top = Math.round((z.trackH - z.h) * c.scrollTop / (z.sh - z.ch)) + "px";
  }
  var oldScroll = c.onscroll;
  c.onscroll = function () { if (oldScroll) oldScroll(); update(); };
  th.onmousedown = function (e) {
    e = e || window.event;
    dragY = e.clientY; dragTop = c.scrollTop; addClass(th, "drag");
    document.onmousemove = function (ev) {
      ev = ev || window.event;
      var z = sizes();
      c.scrollTop = dragTop + (ev.clientY - dragY) * (z.sh - z.ch) / Math.max(1, z.trackH - z.h);
      return false;
    };
    document.onmouseup = function () { document.onmousemove = null; document.onmouseup = null; delClass(th, "drag"); };
    if (e.stopPropagation) e.stopPropagation(); e.cancelBubble = true;
    return false;
  };
  // click on the track: jump a page towards the click
  bar.onmousedown = function (e) {
    e = e || window.event;
    var t = e.target || e.srcElement;
    if (t === th) return false;
    var r = th.getBoundingClientRect();
    c.scrollTop += (e.clientY < r.top ? -1 : 1) * (c.clientHeight - 40);
    return false;
  };
  window.onresize = update;
  setInterval(update, 300);           // pages grow/shrink when cards fold or tabs change
  update();
}

// Wait for the host to hand over window.ahk, then start.
(function boot() {
  if (!window.ahk) { setTimeout(boot, 25); return; }
  init();
})();
